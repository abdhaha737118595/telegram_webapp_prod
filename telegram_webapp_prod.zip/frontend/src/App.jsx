import React from 'react'
import Admin from './pages/Admin'
export default function App(){
  return <Admin />
}
